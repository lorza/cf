<?php
echo $_SERVER['DOCUMENT_ROOT'];
?>